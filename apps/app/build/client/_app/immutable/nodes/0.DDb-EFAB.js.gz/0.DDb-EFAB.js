import"../chunks/DsnmJJEf.js";import{ak as X,al as x,m as P,l as g,a as u,d as Y,p as Z,ad as ee,f as _,am as ae,an as te,b as se,c as t,ao as re,n as m,r as s,h as f,N as oe}from"../chunks/B9G1ZdG6.js";import{i as I}from"../chunks/nszvv3va.js";import{l as z,b as M,s as R,a as ne}from"../chunks/WQTESPAT.js";import{o as le,a as B,d as ie,e as ce,g as de,c as me,h as fe}from"../chunks/quTv0IwE.js";import{g as ue}from"../chunks/DU25-fHU.js";import{B as pe}from"../chunks/DcA2T2Mn.js";import"../chunks/DgnxMCRj.js";import{I as j,c as k}from"../chunks/j2jMjjYa.js";import{S as ve}from"../chunks/DseRBehA.js";import{U as he}from"../chunks/BxbDESPL.js";const A=x(null),xe=x(!1);le(B,e=>{A.set(e),xe.set(!0)});X(A,e=>!!e);const N=x(null),q=x(!1);async function ge(e){q.set(!0);try{const a=ie(ce,"users",e.uid),n=await de(a);if(n.exists()){const r=n.data();return N.set(r),r}else{const r={uid:e.uid,email:e.email,displayName:e.displayName||"ユーザー",photoURL:e.photoURL||void 0,role:"jobseeker",createdAt:new Date,updatedAt:new Date};return await me(a,r),N.set(r),r}}catch(a){return console.error("プロファイル取得エラー:",a),null}finally{q.set(!1)}}function _e(e,a){const n=z(a,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"}]];j(e,M({name:"house"},()=>n,{get iconNode(){return r},children:(i,h)=>{var o=P(),c=g(o);k(c,a,"default",{}),u(i,o)},$$slots:{default:!0}}))}function $e(e,a){const n=z(a,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"m16 17 5-5-5-5"}],["path",{d:"M21 12H9"}],["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"}]];j(e,M({name:"log-out"},()=>n,{get iconNode(){return r},children:(i,h)=>{var o=P(),c=g(o);k(c,a,"default",{}),u(i,o)},$$slots:{default:!0}}))}function be(e,a){const n=z(a,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z"}]];j(e,M({name:"message-square"},()=>n,{get iconNode(){return r},children:(i,h)=>{var o=P(),c=g(o);k(c,a,"default",{}),u(i,o)},$$slots:{default:!0}}))}async function ye(){try{await fe(B),ue("/")}catch(e){console.error("ログアウトエラー:",e)}}var we=_('<a href="/jobs" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">求人を探す</a> <a href="/post" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">求人を投稿</a> <a href="/profile" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">プロフィール</a> <button class="text-gray-700 hover:text-red-600 px-3 py-2 rounded-md text-sm font-medium flex items-center"><!> ログアウト</button>',1),Ne=_('<a href="/auth/login" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">ログイン</a> <a href="/auth/register" class="bg-blue-600 text-white hover:bg-blue-700 px-4 py-2 rounded-md text-sm font-medium">新規登録</a>',1),Pe=_('<nav class="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t"><div class="flex justify-around py-2"><a href="/" class="flex flex-col items-center p-2 text-gray-600 hover:text-blue-600"><!> <span class="text-xs mt-1">ホーム</span></a> <a href="/jobs" class="flex flex-col items-center p-2 text-gray-600 hover:text-blue-600"><!> <span class="text-xs mt-1">探す</span></a> <a href="/messages" class="flex flex-col items-center p-2 text-gray-600 hover:text-blue-600"><!> <span class="text-xs mt-1">メッセージ</span></a> <a href="/profile" class="flex flex-col items-center p-2 text-gray-600 hover:text-blue-600"><!> <span class="text-xs mt-1">プロフィール</span></a></div></nav>'),ze=_('<div class="min-h-screen bg-gray-50"><header class="bg-white shadow-sm border-b"><div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"><div class="flex justify-between items-center h-16"><div class="flex items-center"><a href="/" class="flex items-center space-x-2"><!> <span class="font-bold text-xl text-gray-900">ミセトモ</span></a> <span class="ml-2 text-sm text-gray-500">地域で見つかる、短期のお仕事</span></div> <nav class="flex items-center space-x-4"><!></nav></div></div></header> <main><!></main> <!></div>');function qe(e,a){Z(a,!0);const[n,r]=ne(),i=()=>R(A,"$user",n),h=()=>R(N,"$userProfile",n);ee(()=>{i()&&!h()&&ge(i())});var o=ze();ae(l=>{re.title="ミセトモ - 地域で見つかる短期のお仕事"});var c=t(o),H=t(c),L=t(H),$=t(L),U=t($),V=t(U);pe(V,{class:"h-8 w-8 text-blue-600"}),m(2),s(U),m(2),s($);var D=f($,2),C=t(D);{var O=l=>{var d=we(),p=f(g(d),6);p.__click=[ye];var v=t(p);$e(v,{class:"h-4 w-4 mr-1"}),m(),s(p),u(l,d)},E=l=>{var d=Ne();m(2),u(l,d)};I(C,l=>{i()?l(O):l(E,!1)})}s(D),s(L),s(H),s(c);var b=f(c,2),F=t(b);te(F,()=>a.children??oe),s(b);var G=f(b,2);{var J=l=>{var d=Pe(),p=t(d),v=t(p),K=t(v);_e(K,{class:"h-6 w-6"}),m(2),s(v);var y=f(v,2),Q=t(y);ve(Q,{class:"h-6 w-6"}),m(2),s(y);var w=f(y,2),T=t(w);be(T,{class:"h-6 w-6"}),m(2),s(w);var S=f(w,2),W=t(S);he(W,{class:"h-6 w-6"}),m(2),s(S),s(p),s(d),u(l,d)};I(G,l=>{i()&&l(J)})}s(o),u(e,o),se(),r()}Y(["click"]);export{qe as component};
