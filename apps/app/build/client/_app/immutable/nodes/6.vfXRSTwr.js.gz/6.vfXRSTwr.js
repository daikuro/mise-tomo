import"../chunks/DsnmJJEf.js";import{m as w,l as b,a as x,d as wa,p as $a,f as y,c as a,s as Ve,h as t,t as j,b as ka,i as te,g as _,n as Z,r as e,ai as Ca,j as i}from"../chunks/B9G1ZdG6.js";import{i as Ee}from"../chunks/nszvv3va.js";import{I as $,c as k,e as ee,i as ae,a as Na,r as za,f as Ia}from"../chunks/j2jMjjYa.js";import{g as ja}from"../chunks/DU25-fHU.js";import"../chunks/DgnxMCRj.js";import{l as C,b as N}from"../chunks/WQTESPAT.js";import{B as Pa}from"../chunks/DmKaB3Lt.js";import{S as Sa,M as Aa,D as Ma,C as Ra}from"../chunks/CVHt0n6s.js";import{C as qa}from"../chunks/CAF9SmLa.js";import{C as Ge}from"../chunks/DGMipRh7.js";function Da(o,r){const s=C(r,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const u=[["path",{d:"m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526"}],["circle",{cx:"12",cy:"8",r:"6"}]];$(o,N({name:"award"},()=>s,{get iconNode(){return u},children:(c,g)=>{var l=w(),p=b(l);k(p,r,"default",{}),x(c,l)},$$slots:{default:!0}}))}function Ba(o,r){const s=C(r,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const u=[["path",{d:"m15 18-6-6 6-6"}]];$(o,N({name:"chevron-left"},()=>s,{get iconNode(){return u},children:(c,g)=>{var l=w(),p=b(l);k(p,r,"default",{}),x(c,l)},$$slots:{default:!0}}))}function Ta(o,r){const s=C(r,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const u=[["path",{d:"M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5"}]];$(o,N({name:"heart"},()=>s,{get iconNode(){return u},children:(c,g)=>{var l=w(),p=b(l);k(p,r,"default",{}),x(c,l)},$$slots:{default:!0}}))}function Fa(o,r){const s=C(r,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const u=[["circle",{cx:"18",cy:"5",r:"3"}],["circle",{cx:"6",cy:"12",r:"3"}],["circle",{cx:"18",cy:"19",r:"3"}],["line",{x1:"8.59",x2:"15.42",y1:"13.51",y2:"17.49"}],["line",{x1:"15.41",x2:"8.59",y1:"6.51",y2:"10.49"}]];$(o,N({name:"share-2"},()=>s,{get iconNode(){return u},children:(c,g)=>{var l=w(),p=b(l);k(p,r,"default",{}),x(c,l)},$$slots:{default:!0}}))}function Ja(o,r){const s=C(r,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const u=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"}]];$(o,N({name:"shield"},()=>s,{get iconNode(){return u},children:(c,g)=>{var l=w(),p=b(l);k(p,r,"default",{}),x(c,l)},$$slots:{default:!0}}))}function Ka(){history.back()}function Oa(o,r){te(r,!_(r))}function Ha(o,r,s){navigator.share?navigator.share({title:r.title,text:`${r.company}の求人情報`,url:window.location.href}):te(s,!0)}function La(o,r){ja(`/jobs/${r.id}/apply`)}var Va=y('<div class="flex items-center text-green-600"><!> <span class="text-sm">認証済み</span></div>'),Ea=y('<li class="flex items-start"><!> <span class="text-gray-700"> </span></li>'),Ga=y('<li class="flex items-start"><!> <span class="text-gray-700"> </span></li>'),Qa=y('<a class="block p-3 border rounded-lg hover:bg-gray-50 transition-colors"><h4 class="font-medium text-sm mb-1"> </h4> <p class="text-xs text-gray-600 mb-1"> </p> <div class="flex items-center justify-between"><span class="text-xs text-gray-500"> </span> <span class="text-sm font-medium text-blue-600"> </span></div></a>'),Ua=(o,r)=>te(r,!1),Wa=y('<div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"><div class="bg-white rounded-lg p-6 max-w-md w-full"><h3 class="text-lg font-bold mb-4">共有リンク</h3> <input type="text" readonly="" class="w-full p-2 border rounded mb-4"/> <button class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">閉じる</button></div></div>'),Xa=y('<div class="min-h-screen bg-gray-50"><header class="bg-white shadow-sm sticky top-0 z-10"><div class="max-w-6xl mx-auto px-4 py-4"><div class="flex items-center justify-between"><button class="flex items-center text-gray-600 hover:text-gray-900"><!> 戻る</button> <div class="flex gap-2"><button class="p-2 rounded-full hover:bg-gray-100 transition-colors" aria-label="お気に入り"><!></button> <button class="p-2 rounded-full hover:bg-gray-100 transition-colors" aria-label="共有"><!></button></div></div></div></header> <div class="max-w-6xl mx-auto px-4 py-6"><div class="grid lg:grid-cols-3 gap-6"><div class="lg:col-span-2 space-y-6"><div class="bg-white rounded-lg shadow-md p-6"><div class="mb-4"><span class="inline-block px-3 py-1 bg-blue-100 text-blue-600 rounded-full text-sm"> </span></div> <h1 class="text-2xl font-bold mb-4"> </h1> <div class="flex items-center gap-4 mb-4"><div class="flex items-center"><!> <span class="font-medium"> </span></div> <!></div> <div class="flex items-center gap-4 mb-6"><div class="flex items-center"><!> <span class="ml-1 font-medium"> </span> <span class="ml-1 text-gray-500 text-sm"> </span></div></div> <div class="grid sm:grid-cols-2 gap-4"><div class="flex items-start"><!> <div><p class="font-medium"> </p> <p class="text-sm text-gray-600"> </p></div></div> <div class="flex items-center"><!> <span class="font-medium text-lg text-blue-600"> </span></div> <div class="flex items-center"><!> <span> </span></div> <div class="flex items-center"><!> <span> </span></div></div></div> <div class="bg-white rounded-lg shadow-md p-6"><h2 class="text-xl font-bold mb-4">仕事内容</h2> <p class="whitespace-pre-line text-gray-700"> </p></div> <div class="bg-white rounded-lg shadow-md p-6"><h2 class="text-xl font-bold mb-4">応募条件</h2> <ul class="space-y-2"></ul></div> <div class="bg-white rounded-lg shadow-md p-6"><h2 class="text-xl font-bold mb-4">待遇・福利厚生</h2> <ul class="space-y-2"></ul></div> <div class="bg-white rounded-lg shadow-md p-6"><h2 class="text-xl font-bold mb-4">企業情報</h2> <div class="space-y-3"><div class="flex items-center justify-between"><span class="text-gray-600">企業名</span> <span class="font-medium"> </span></div> <div class="flex items-center justify-between"><span class="text-gray-600">設立</span> <span class="font-medium"> </span></div> <div class="flex items-center justify-between"><span class="text-gray-600">従業員数</span> <span class="font-medium"> </span></div> <p class="text-gray-700 pt-3 border-t"> </p></div></div></div> <div class="lg:col-span-1"><div class="bg-white rounded-lg shadow-md p-6 sticky top-20"><div class="mb-4"><div class="flex items-center justify-between mb-2"><span class="text-gray-600">募集人数</span> <span class="font-medium"> </span></div> <div class="flex items-center justify-between"><span class="text-gray-600">現在の応募者</span> <span class="font-medium"> </span></div></div> <button class="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 font-medium transition-colors mb-3">この求人に応募する</button> <button class="w-full border border-blue-600 text-blue-600 py-3 rounded-lg hover:bg-blue-50 font-medium transition-colors">企業に質問する</button> <div class="mt-4 p-3 bg-gray-50 rounded-lg"><div class="flex items-center text-sm text-gray-600"><!> <span>安心の事前確認制度</span></div></div></div> <div class="bg-white rounded-lg shadow-md p-6 mt-6"><h3 class="font-bold mb-4">類似の求人</h3> <div class="space-y-3"></div></div></div></div></div></div> <!>',1);function ot(o,r){$a(r,!0);const s={id:1,title:"カフェスタッフ募集",company:"おしゃれカフェ",location:"渋谷",address:"東京都渋谷区渋谷2-15-1 渋谷クロスタワー 3F",hourlyRate:"¥1,200",duration:"単発OK",rating:4.5,reviewCount:128,category:"飲食・フード",workDate:"2024年1月15日〜",workTime:"10:00-18:00",breakTime:"60分",requiredPeople:5,currentApplicants:12,description:`人気のカフェでスタッフを募集しています！
    
    明るく活気のある職場で、一緒に働きませんか？
    カフェ経験がない方でも、丁寧に研修を行いますので安心してご応募ください。
    
    【仕事内容】
    ・ドリンクの調理、提供
    ・レジ業務
    ・店内清掃
    ・お客様対応`,requirements:["18歳以上の方（高校生不可）","土日祝日に勤務可能な方歓迎","接客業に興味がある方","明るく元気な対応ができる方"],benefits:["交通費全額支給","制服貸与","まかない付き（勤務時間による）","週1日〜OK","未経験者歓迎"],images:["/api/placeholder/600/400","/api/placeholder/600/400","/api/placeholder/600/400"],companyInfo:{name:"おしゃれカフェ",description:"都内に10店舗を展開する人気カフェチェーンです。",employees:"300名",established:"2015年",verified:!0},similarJobs:[{id:2,title:"レストランホールスタッフ",company:"イタリアンレストラン",location:"新宿",hourlyRate:"¥1,300"},{id:3,title:"ファストフード店スタッフ",company:"バーガーショップ",location:"池袋",hourlyRate:"¥1,150"}]};let u=Ve(!1),c=Ve(!1);var g=Xa(),l=b(g),p=a(l),se=a(p),re=a(se),z=a(re);z.__click=[Ka];var Qe=a(z);Ba(Qe,{class:"h-5 w-5 mr-1"}),Z(),e(z);var ie=t(z,2),I=a(ie);I.__click=[Oa,u];var Ue=a(I);{let v=Ca(()=>_(u)?"fill-red-500 text-red-500":"text-gray-600");Ta(Ue,{get class(){return`h-5 w-5 ${_(v)??""}`}})}e(I);var P=t(I,2);P.__click=[Ha,s,c];var We=a(P);Fa(We,{class:"h-5 w-5 text-gray-600"}),e(P),e(ie),e(re),e(se),e(p);var le=t(p,2),ne=a(le),S=a(ne),A=a(S),M=a(A),de=a(M),Xe=a(de,!0);e(de),e(M);var R=t(M,2),Ye=a(R,!0);e(R);var q=t(R,2),D=a(q),oe=a(D);Pa(oe,{class:"h-5 w-5 text-gray-500 mr-2"});var ve=t(oe,2),Ze=a(ve,!0);e(ve),e(D);var ea=t(D,2);{var aa=v=>{var n=Va(),d=a(n);Ge(d,{class:"h-4 w-4 mr-1"}),Z(2),e(n),x(v,n)};Ee(ea,v=>{s.companyInfo.verified&&v(aa)})}e(q);var B=t(q,2),ce=a(B),pe=a(ce);Sa(pe,{class:"h-5 w-5 text-yellow-500 fill-current"});var T=t(pe,2),ta=a(T,!0);e(T);var me=t(T,2),sa=a(me);e(me),e(ce),e(B);var ue=t(B,2),F=a(ue),_e=a(F);Aa(_e,{class:"h-5 w-5 text-gray-500 mr-2 mt-0.5"});var xe=t(_e,2),J=a(xe),ra=a(J,!0);e(J);var fe=t(J,2),ia=a(fe,!0);e(fe),e(xe),e(F);var K=t(F,2),ge=a(K);Ma(ge,{class:"h-5 w-5 text-gray-500 mr-2"});var he=t(ge,2),la=a(he,!0);e(he),e(K);var O=t(K,2),be=a(O);qa(be,{class:"h-5 w-5 text-gray-500 mr-2"});var ye=t(be,2),na=a(ye,!0);e(ye),e(O);var we=t(O,2),$e=a(we);Ra($e,{class:"h-5 w-5 text-gray-500 mr-2"});var ke=t($e,2),da=a(ke,!0);e(ke),e(we),e(ue),e(A);var H=t(A,2),Ce=t(a(H),2),oa=a(Ce,!0);e(Ce),e(H);var L=t(H,2),Ne=t(a(L),2);ee(Ne,21,()=>s.requirements,ae,(v,n)=>{var d=Ea(),m=a(d);Ge(m,{class:"h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0"});var f=t(m,2),h=a(f,!0);e(f),e(d),j(()=>i(h,_(n))),x(v,d)}),e(Ne),e(L);var V=t(L,2),ze=t(a(V),2);ee(ze,21,()=>s.benefits,ae,(v,n)=>{var d=Ga(),m=a(d);Da(m,{class:"h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0"});var f=t(m,2),h=a(f,!0);e(f),e(d),j(()=>i(h,_(n))),x(v,d)}),e(ze),e(V);var Ie=t(V,2),je=t(a(Ie),2),E=a(je),Pe=t(a(E),2),va=a(Pe,!0);e(Pe),e(E);var G=t(E,2),Se=t(a(G),2),ca=a(Se,!0);e(Se),e(G);var Q=t(G,2),Ae=t(a(Q),2),pa=a(Ae,!0);e(Ae),e(Q);var Me=t(Q,2),ma=a(Me,!0);e(Me),e(je),e(Ie),e(S);var Re=t(S,2),U=a(Re),W=a(U),X=a(W),qe=t(a(X),2),ua=a(qe);e(qe),e(X);var De=t(X,2),Be=t(a(De),2),_a=a(Be);e(Be),e(De),e(W);var Te=t(W,2);Te.__click=[La,s];var Fe=t(Te,4),Je=a(Fe),xa=a(Je);Ja(xa,{class:"h-4 w-4 mr-2"}),Z(2),e(Je),e(Fe),e(U);var Ke=t(U,2),Oe=t(a(Ke),2);ee(Oe,21,()=>s.similarJobs,ae,(v,n)=>{var d=Qa(),m=a(d),f=a(m,!0);e(m);var h=t(m,2),ha=a(h,!0);e(h);var He=t(h,2),Y=a(He),ba=a(Y,!0);e(Y);var Le=t(Y,2),ya=a(Le,!0);e(Le),e(He),e(d),j(()=>{Na(d,"href",`/jobs/${_(n).id}`),i(f,_(n).title),i(ha,_(n).company),i(ba,_(n).location),i(ya,_(n).hourlyRate)}),x(v,d)}),e(Oe),e(Ke),e(Re),e(ne),e(le),e(l);var fa=t(l,2);{var ga=v=>{var n=Wa(),d=a(n),m=t(a(d),2);za(m),Ia(m,window.location.href);var f=t(m,2);f.__click=[Ua,c],e(d),e(n),x(v,n)};Ee(fa,v=>{_(c)&&v(ga)})}j(()=>{i(Xe,s.category),i(Ye,s.title),i(Ze,s.company),i(ta,s.rating),i(sa,`(${s.reviewCount??""}件)`),i(ra,s.location),i(ia,s.address),i(la,s.hourlyRate),i(na,s.workDate),i(da,s.workTime),i(oa,s.description),i(va,s.companyInfo.name),i(ca,s.companyInfo.established),i(pa,s.companyInfo.employees),i(ma,s.companyInfo.description),i(ua,`${s.requiredPeople??""}名`),i(_a,`${s.currentApplicants??""}名`)}),x(o,g),ka()}wa(["click"]);export{ot as component};
